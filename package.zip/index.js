const { 
    Client, 
    GatewayIntentBits, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    EmbedBuilder, 
    StringSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ChannelType, 
    PermissionFlagsBits,
    REST,
    Routes,
    SlashCommandBuilder
} = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages
    ]
});

const TOKEN = "MTU0NTkzNDk3NzkwMjk2ODk0Mg.Gn3M49.ccsApn_q3SJLN6rO6P87QU82AELSrL5XPfNWTA"; 
const CLIENT_ID = "1545934977902968942"; 

// 🌐 CONFIGURAÇÃO DE SERVIDORES E CARGOS
const ID_SERVIDOR_PRINCIPAL = "1538590303106240543"; 

// 🎯 CARGO ATUALIZADO DE COMPRA
const CARGO_COMPRADOR_ID = "1546222150820565052"; 
const CARGO_RESGATE_CODIGO_ID = "1546207205605507112";
const CARGO_BANIDO_ID = "1545961077614059600";
const CARGO_ALLOWLIST_ID = "1544150643911032852";

// 🔒 CARGO EXCLUSIVO PARA DAR UNBAN
const CARGO_UNBAN_PERMITIDO_ID = "1546171008317390968";

// 🤖 CARGO AUTOMÁTICO AO ENTRAR NO SERVIDOR
const CARGO_AUTO_ENTRADA_ID = "1546171458890375301";

// CANAIS ESPECÍFICOS
const CANAL_LIMPAR_CHAT = "1544148100288094241";
const CANAL_BATE_PAPO = "1540779962636836964";

const BANNER_URL = "https://cdn.discordapp.com/attachments/1545937369642041364/1546159083889893456/gemini-2.5-flash-image_QUERO_UM_BANNER_IGAUL_A_ESSE_SO_QUE_A_DIZER_K1NG_SUP_EM_SIM_EM_PEQUENO_MAS_SO_O_-0.jpg?ex=6a9ec45b&is=6a9d72db&hm=343e697c4e77e7c5277740f49c51b36f528e5700aac4150604a1bac59ffa273e&";

// BANCO DE DADOS DE CÓDIGOS EM MEMÓRIA
const codigosValidos = new Set([
    "BETA1", "BETA2", "BETA3", "BETA4", "BETA5",
    "TRY-VOLTOU1", "TRY-VOLTOU2", "TRY-VOLTOU3", "TRY-VOLTOU4", "TRY-VOLTOU5"
]);

const callsAtivas = new Map();

// REGISTRO DE COMANDOS SLASH
const commands = [
    new SlashCommandBuilder().setName('painel-ticket').setDescription('Envia o Painel de Atendimento'),
    new SlashCommandBuilder().setName('painel-unban').setDescription('Envia o Painel de Unban'),
    new SlashCommandBuilder().setName('painel-allowlist').setDescription('Envia o Painel de Allowlist'),
    new SlashCommandBuilder().setName('criar-call-painel').setDescription('Envia o painel de criação de Calls Temp'),
    new SlashCommandBuilder().setName('connect').setDescription('Envia a caixa de IP/Connect do servidor'),
    new SlashCommandBuilder().setName('gerarcodigos').setDescription('Gera uma lista de códigos válidos')
        .addIntegerOption(opt => opt.setName('quantidade').setDescription('Quantidade (1 a 100)').setMinValue(1).setMaxValue(100).setRequired(true))
        .addChannelOption(opt => opt.setName('canal').setDescription('Canal destino').setRequired(false)),
    new SlashCommandBuilder().setName('ban').setDescription('Aplica o cargo de Banido ao utilizador')
        .addUserOption(opt => opt.setName('usuario').setDescription('Utilizador').setRequired(true))
        .addStringOption(opt => opt.setName('motivo').setDescription('Motivo').setRequired(false)),
    new SlashCommandBuilder().setName('unban').setDescription('Remove o cargo de Banido por ID (Requer Cargo Especial)')
        .addStringOption(opt => opt.setName('id').setDescription('ID do utilizador').setRequired(true)),
    new SlashCommandBuilder().setName('mute').setDescription('Silencia um utilizador')
        .addUserOption(opt => opt.setName('usuario').setDescription('Utilizador').setRequired(true))
        .addIntegerOption(opt => opt.setName('minutos').setDescription('Tempo em minutos').setRequired(true)),
    new SlashCommandBuilder().setName('dm').setDescription('Envia mensagem privada')
        .addUserOption(opt => opt.setName('usuario').setDescription('Utilizador').setRequired(true))
        .addStringOption(opt => opt.setName('mensagem').setDescription('Conteúdo').setRequired(true)),
    new SlashCommandBuilder().setName('embed').setDescription('Envia mensagem em Embed')
        .addStringOption(opt => opt.setName('titulo').setDescription('Título').setRequired(true))
        .addStringOption(opt => opt.setName('descricao').setDescription('Descrição').setRequired(true)),
    new SlashCommandBuilder().setName('lock').setDescription('Bloqueia o canal'),
    new SlashCommandBuilder().setName('unlock').setDescription('Desbloqueia o canal')
].map(cmd => cmd.toJSON());

client.once('ready', async () => {
    console.log(`🤖 Bot K1NG SUP online em ${client.user.tag}!`);
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    try {
        await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
        console.log('✅ Comandos Slash registrados!');
    } catch (error) {
        console.error('❌ Erro nos comandos:', error);
    }
});

// 📌 ATRIBUIR CARGO AUTOMÁTICO AO ENTRAR
client.on('guildMemberAdd', async (member) => {
    try {
        await member.roles.add(CARGO_AUTO_ENTRADA_ID);
        console.log(`✅ Cargo automático (${CARGO_AUTO_ENTRADA_ID}) adicionado ao membro ${member.user.tag}`);
    } catch (error) {
        console.error(`❌ Erro ao atribuir cargo automático a ${member.user.tag}:`, error);
    }
});

// FUNÇÃO CORRIGIDA PARA GERAR E REGISTAR CÓDIGOS
function gerarCodigoUnico() {
    const caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let codigo = "TRY-";
    for (let i = 0; i < 8; i++) {
        codigo += caracteres.charAt(Math.floor(Math.random() * caracteres.length));
    }
    codigosValidos.add(codigo); // REGISTA NO BANCO DE MEMÓRIA
    return codigo;
}

function criarEmbedBanner(titulo, descricao) {
    return new EmbedBuilder()
        .setTitle(titulo)
        .setDescription(descricao)
        .setColor('#2B2D31')
        .setImage(BANNER_URL)
        .setFooter({ text: 'K1NG SUP • Sistema Oficial' })
        .setTimestamp();
}

function criarEmbedConnect(minutosOuSegundosTexto) {
    return new EmbedBuilder()
        .setTitle('🎮 Conectar nos servidores')
        .setDescription(
            `👥 \`306\` **jogadores online no total**\n` +
            `Clica no botão do servidor pra **entrar direto**, ou abre o FiveM, aperta \`F8\` e cola o comando.\n\n` +
            `🟢 **TRYHARD** · \`306\` **jogando agora de** \`1000\`\n\n` +
            `\`\`\`connect th5v5.com\`\`\``
        )
        .setColor('#1E90FF')
        .setImage(BANNER_URL)
        .setFooter({ text: `Atualiza a cada 1min · última atualização ${minutosOuSegundosTexto}` });
}

function criarBotoesGerenciamentoTicket(incluirUnban = false) {
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('btn_assumir_ticket').setLabel('✋ Assumir Ticket').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('btn_fechar_ticket').setLabel('Fechar Ticket').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('btn_renomear_ticket').setLabel('Renomear').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('btn_notificar_jogador').setLabel('Notificar Jogador').setStyle(ButtonStyle.Primary)
    );

    if (incluirUnban) {
        row.addComponents(
            new ButtonBuilder().setCustomId('btn_remover_ban').setLabel('🔓 Remover Ban').setStyle(ButtonStyle.Success)
        );
    }
    return row;
}

// --- COMANDOS DE TEXTO (!limpar / !limpa) ---
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.content.startsWith('!')) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const comando = args.shift().toLowerCase();

    if (comando === 'limpar' || comando === 'limpa') {
        await message.delete().catch(() => {});

        if (message.channel.id !== CANAL_LIMPAR_CHAT && message.channel.id !== CANAL_BATE_PAPO) {
            const msgErro = await message.channel.send({ 
                embeds: [criarEmbedBanner('❌ CANAL INCORRETO', `Utilize este comando apenas em <#${CANAL_LIMPAR_CHAT}> ou <#${CANAL_BATE_PAPO}>.`)] 
            });
            return setTimeout(() => msgErro.delete().catch(() => {}), 4000);
        }

        let quantidade = parseInt(args[0]) || 100;
        if (quantidade < 1) quantidade = 1;
        if (quantidade > 100) quantidade = 100;

        try {
            const apagadas = await message.channel.bulkDelete(quantidade, true);
            const msgAviso = await message.channel.send({ 
                embeds: [criarEmbedBanner('🧹 CHAT LIMPO', `Foram removidas **${apagadas.size}** mensagens do chat.`)] 
            });
            setTimeout(() => msgAviso.delete().catch(() => {}), 5000);
        } catch (err) {
            const msgErro = await message.channel.send('❌ Não foi possível apagar mensagens com mais de 14 dias.');
            setTimeout(() => msgErro.delete().catch(() => {}), 5000);
        }
    }
});

// --- INTERAÇÕES SLASH (/) ---
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    await interaction.deferReply({ ephemeral: true }).catch(() => {});

    if (interaction.commandName === 'connect') {
        let tempoPassado = 0;

        const msgStatus = await interaction.channel.send({
            embeds: [criarEmbedConnect('há 1 segundo')]
        });

        const intervalId = setInterval(async () => {
            tempoPassado += 10;
            let textoTempo = '';

            if (tempoPassado < 60) {
                textoTempo = `há ${tempoPassado} segundos`;
            } else {
                const minutos = Math.floor(tempoPassado / 60);
                textoTempo = minutos === 1 ? 'há 1 minuto' : `há ${minutos} minutos`;
            }

            if (tempoPassado >= 3600) {
                textoTempo = 'há 1 hora';
                clearInterval(intervalId);
            }

            await msgStatus.edit({
                embeds: [criarEmbedConnect(textoTempo)]
            }).catch(() => clearInterval(intervalId));
        }, 10000);

        return interaction.editReply({ content: '✅ Embed de Connect enviado!' });
    }

    if (interaction.commandName === 'ban') {
        const usuario = interaction.options.getUser('usuario');
        const motivo = interaction.options.getString('motivo') || 'Sem motivo especificado.';
        const membro = await interaction.guild.members.fetch(usuario.id).catch(() => null);

        if (!membro) return interaction.editReply({ content: '❌ Utilizador não encontrado no servidor.' });

        try {
            await membro.roles.add(CARGO_BANIDO_ID);
            await membro.roles.remove(CARGO_ALLOWLIST_ID).catch(() => {});
            await membro.roles.remove(CARGO_RESGATE_CODIGO_ID).catch(() => {});
            await interaction.editReply({ content: `✅ O utilizador <@${usuario.id}> recebeu o cargo de Banido pelo motivo: **${motivo}**` });
        } catch (err) {
            return interaction.editReply({ content: '❌ Erro ao atribuir o cargo de banido.' });
        }
        return;
    }

    if (interaction.commandName === 'unban') {
        if (!interaction.member.roles.cache.has(CARGO_UNBAN_PERMITIDO_ID)) {
            return interaction.editReply({ content: `❌ Você não tem permissão para remover bans. Necessário o cargo <@&${CARGO_UNBAN_PERMITIDO_ID}>.` });
        }

        const id = interaction.options.getString('id');
        const membro = await interaction.guild.members.fetch(id).catch(() => null);

        if (!membro) return interaction.editReply({ content: '❌ Utilizador não encontrado no servidor.' });

        try {
            await membro.roles.remove(CARGO_BANIDO_ID);
            await membro.roles.add(CARGO_ALLOWLIST_ID).catch(() => {});
            return interaction.editReply({ content: `✅ O cargo de banido foi removido do utilizador <@${id}>.` });
        } catch (err) {
            return interaction.editReply({ content: '❌ Erro ao remover o cargo de banido.' });
        }
    }

    if (interaction.commandName === 'criar-call-painel') {
        const embed = new EmbedBuilder()
            .setTitle('CRIAR CALL - TRYHARD')
            .setDescription(
                '**Criação:** clique em **CRIAR CALL**, escolha de **2 a 99 vagas** e entre no canal de voz criado para seu squad.\n' +
                '**Acesso:** é necessário ter **Allowlist** para criar e entrar nas calls.\n\n' +
                '───────────────────────────────────────\n\n' +
                '**Limite:** uma call ativa por pessoa.\n' +
                '**Encerramento:** a call é apagada após **5 minutos vazia**. Para apagar sua própria call antes disso, use **EXCLUIR CALL**.'
            )
            .setColor('#2B2D31');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('btn_abrir_modal_call').setLabel('CRIAR CALL').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('btn_excluir_call').setLabel('EXCLUIR CALL').setStyle(ButtonStyle.Secondary)
        );

        await interaction.channel.send({ embeds: [embed], components: [row] });
        return interaction.editReply({ content: '✅ Painel de Call criado com sucesso!' });
    }

    if (interaction.commandName === 'painel-allowlist') {
        const embed = criarEmbedBanner('📜 PAINEL DE ALLOWLIST', 'Clique no botão abaixo para resgatar seu código e liberar seu acesso.');
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('btn_resgatar_allowlist').setLabel('Resgatar Codiguinho').setStyle(ButtonStyle.Primary)
        );
        await interaction.channel.send({ embeds: [embed], components: [row] });
        return interaction.editReply({ content: '✅ Painel enviado!' });
    }

    if (interaction.commandName === 'painel-ticket') {
        const embed = criarEmbedBanner('🎫 CENTRAL DE ATENDIMENTO', 'Selecione a opção desejada:');
        const selectMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_painel_principal')
                .setPlaceholder('Escolha uma opção...')
                .addOptions([
                    { label: 'Recrutamento', value: 'op_recrutamento', emoji: '📋' },
                    { label: 'Suporte Geral', value: 'op_suporte', emoji: '🎫' },
                    { label: 'Loja / Resgatar Codiguinho', value: 'op_loja', emoji: '🛒' }
                ])
        );
        await interaction.channel.send({ embeds: [embed], components: [selectMenu] });
        return interaction.editReply({ content: '✅ Painel enviado!' });
    }

    if (interaction.commandName === 'painel-unban') {
        const embed = criarEmbedBanner('🔓 PAINEL DE UNBAN', 'Selecione abaixo para solicitar unban.');
        const selectUnban = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_painel_unban')
                .setPlaceholder('Abrir ticket...')
                .addOptions([{ label: 'Solicitar Unban', value: 'op_unban_solicitar', emoji: '🔓' }])
        );
        await interaction.channel.send({ embeds: [embed], components: [selectUnban] });
        return interaction.editReply({ content: '✅ Painel enviado!' });
    }

    // 🔑 COMANDO GERAR CÓDIGOS COM SUPORTE DE ATÉ 100 CÓDIGOS SUPORTADO
    if (interaction.commandName === 'gerarcodigos') {
        const qtd = interaction.options.getInteger('quantidade');
        const canal = interaction.options.getChannel('canal') || interaction.channel;
        
        const novosCodigos = [];
        for (let i = 0; i < qtd; i++) {
            novosCodigos.push(gerarCodigoUnico());
        }

        // Divide a mensagem em blocos para evitar ultrapassar o limite de caracteres do Discord
        let conteudo = "";
        for (let i = 0; i < novosCodigos.length; i++) {
            const linha = `\`${novosCodigos[i]}\`\n`;
            if ((conteudo + linha).length > 3900) {
                await canal.send({ embeds: [criarEmbedBanner(`🔑 CÓDIGOS GERADOS (${i}/${qtd})`, conteudo)] });
                conteudo = "";
            }
            conteudo += linha;
        }

        if (conteudo.length > 0) {
            await canal.send({ embeds: [criarEmbedBanner(`🔑 CÓDIGOS GERADOS (${qtd})`, conteudo)] });
        }

        return interaction.editReply({ content: `✅ **${qtd}** códigos gerados e registrados com sucesso!` });
    }
});

// --- AÇÕES DOS BOTÕES E MODAIS ---
client.on('interactionCreate', async (interaction) => {

    if (interaction.isButton() && interaction.customId === 'btn_assumir_ticket') {
        await interaction.reply({ 
            embeds: [criarEmbedBanner('✋ TICKET ASSUMIDO', `Este ticket agora está sendo atendido por <@${interaction.user.id}>.`)] 
        });
        return;
    }

    if (interaction.isButton() && interaction.customId === 'btn_renomear_ticket') {
        const modal = new ModalBuilder().setCustomId('modal_renomear_ticket').setTitle('Renomear Ticket');
        const inputNome = new TextInputBuilder()
            .setCustomId('novo_nome_canal')
            .setLabel('Novo nome para o canal:')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('ex: ticket-fechado')
            .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(inputNome));
        return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_renomear_ticket') {
        await interaction.deferReply({ ephemeral: true });
        const novoNome = interaction.fields.getTextInputValue('novo_nome_canal');
        await interaction.channel.setName(novoNome).catch(() => {});
        return interaction.editReply({ content: `✅ O ticket foi renomeado para **${novoNome}**.` });
    }

    if (interaction.isButton() && interaction.customId === 'btn_notificar_jogador') {
        await interaction.deferReply({ ephemeral: true });
        const overwrite = interaction.channel.permissionOverwrites.cache.find(o => o.type === 1 && o.id !== client.user.id);

        if (!overwrite) {
            return interaction.editReply({ content: '❌ Não foi possível encontrar o criador deste ticket.' });
        }

        const membro = await interaction.guild.members.fetch(overwrite.id).catch(() => null);
        if (membro) {
            try {
                await membro.send({
                    embeds: [
                        criarEmbedBanner(
                            '🔔 NOTIFICAÇÃO DE SUPORTE',
                            `Olá <@${membro.id}>, a equipe de atendimento respondeu ao seu ticket!\n\nPor favor, retorne ao canal <#${interaction.channel.id}> para dar continuidade.`
                        )
                    ]
                });
                return interaction.editReply({ content: `✅ Notificação enviada via DM para <@${membro.id}>!` });
            } catch (err) {
                return interaction.editReply({ content: '⚠️ Não foi possível enviar DM para o jogador (mensagens privadas desativadas).' });
            }
        }
        return interaction.editReply({ content: '❌ Jogador não encontrado no servidor.' });
    }

    // CALLS TEMPORÁRIAS
    if (interaction.isButton() && interaction.customId === 'btn_abrir_modal_call') {
        if (!interaction.member.roles.cache.has(CARGO_ALLOWLIST_ID)) {
            return interaction.reply({ content: '❌ Necessário ter **Allowlist** para criar uma call.', ephemeral: true });
        }
        if (callsAtivas.has(interaction.user.id)) {
            return interaction.reply({ content: '⚠️ Você já tem uma call ativa!', ephemeral: true });
        }

        const modal = new ModalBuilder().setCustomId('modal_criar_call').setTitle('Criar Call');
        const inputVagas = new TextInputBuilder()
            .setCustomId('vagas_call')
            .setLabel('Quantidade de vagas (2 a 99):')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Ex: 4')
            .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(inputVagas));
        return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_criar_call') {
        await interaction.deferReply({ ephemeral: true });
        const vagas = parseInt(interaction.fields.getTextInputValue('vagas_call'));

        if (isNaN(vagas) || vagas < 2 || vagas > 99) {
            return interaction.editReply({ content: '❌ Informe um número válido de vagas entre 2 e 99.' });
        }

        const canalVoz = await interaction.guild.channels.create({
            name: `Call de ${interaction.user.username}`,
            type: ChannelType.GuildVoice,
            userLimit: vagas,
            permissionOverwrites: [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.Connect] },
                { id: CARGO_ALLOWLIST_ID, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] }
            ]
        });

        callsAtivas.set(interaction.user.id, canalVoz.id);
        return interaction.editReply({ content: `✅ Sua call foi criada em ${canalVoz}!` });
    }

    if (interaction.isButton() && interaction.customId === 'btn_excluir_call') {
        const canalId = callsAtivas.get(interaction.user.id);
        if (!canalId) return interaction.reply({ content: '❌ Você não possui nenhuma call ativa para excluir.', ephemeral: true });

        const canal = interaction.guild.channels.cache.get(canalId);
        if (canal) await canal.delete().catch(() => {});

        callsAtivas.delete(interaction.user.id);
        return interaction.reply({ content: '🗑️ Sua call foi excluída com sucesso!', ephemeral: true });
    }

    // 🎁 RESGATE DE CODIGUINHO CORRIGIDO
    if (interaction.isButton() && interaction.customId === 'btn_resgatar_allowlist') {
        const modal = new ModalBuilder().setCustomId('modal_resgatar_codigo').setTitle('Resgatar Código');
        const input = new TextInputBuilder().setCustomId('codigo_input').setLabel('Insira seu Código:').setStyle(TextInputStyle.Short).setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_resgatar_codigo') {
        await interaction.deferReply({ ephemeral: true });
        const codigo = interaction.fields.getTextInputValue('codigo_input').trim().toUpperCase();

        if (codigosValidos.has(codigo)) {
            codigosValidos.delete(codigo); // REMOVE O CÓDIGO DA MEMÓRIA
            
            const guildPrincipal = client.guilds.cache.get(ID_SERVIDOR_PRINCIPAL) || interaction.guild;
            const membro = await guildPrincipal.members.fetch(interaction.user.id).catch(() => null);

            if (membro) {
                // ATRIBUI OS CARGOS SOLICITADOS
                await membro.roles.add(CARGO_ALLOWLIST_ID).catch(() => {});
                await membro.roles.add(CARGO_RESGATE_CODIGO_ID).catch(() => {});
                await membro.roles.add(CARGO_COMPRADOR_ID).catch(() => {}); // ID: 1546222150820565052

                return interaction.editReply({ 
                    content: `✅ **Código Válido!**\nVocê recebeu os cargos:\n• <@&${CARGO_ALLOWLIST_ID}>\n• <@&${CARGO_RESGATE_CODIGO_ID}>\n• <@&${CARGO_COMPRADOR_ID}>` 
                });
            }
        } else {
            return interaction.editReply({ content: '❌ **Código inválido ou já utilizado.**' });
        }
    }

    // ABRIR TICKETS
    if (interaction.isStringSelectMenu() && (interaction.customId === 'select_painel_principal' || interaction.customId === 'select_painel_unban')) {
        await interaction.deferReply({ ephemeral: true });
        const prefixo = interaction.customId === 'select_painel_unban' ? 'unban' : 'ticket';
        const channelName = `${prefixo}-${interaction.user.username}`;

        const canal = await interaction.guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            permissionOverwrites: [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
            ]
        });

        await interaction.editReply({ content: `✅ Ticket criado em ${canal}!` });
        await canal.send({ 
            embeds: [criarEmbedBanner('🎫 ATENDIMENTO INICIADO', `Olá <@${interaction.user.id}>, aguarde a equipe de suporte.`)], 
            components: [criarBotoesGerenciamentoTicket(prefixo === 'unban')] 
        });
    }

    if (interaction.isButton() && interaction.customId === 'btn_remover_ban') {
        if (!interaction.member.roles.cache.has(CARGO_UNBAN_PERMITIDO_ID)) {
            return interaction.reply({ content: `❌ Você não tem permissão para usar este botão. Apenas membros com o cargo <@&${CARGO_UNBAN_PERMITIDO_ID}> podem aceitar unbans.`, ephemeral: true });
        }

        const modal = new ModalBuilder().setCustomId('modal_remover_ban').setTitle('Remover Banimento');
        const input = new TextInputBuilder().setCustomId('motivo_unban').setLabel('Motivo do Unban:').setStyle(TextInputStyle.Paragraph).setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_remover_ban') {
        await interaction.deferReply();
        const motivo = interaction.fields.getTextInputValue('motivo_unban');
        const username = interaction.channel.name.replace(/^unban-/, '');

        const guildPrincipal = client.guilds.cache.get(ID_SERVIDOR_PRINCIPAL) || interaction.guild;
        await guildPrincipal.members.fetch();
        const membro = guildPrincipal.members.cache.find(m => m.user.username.toLowerCase() === username.toLowerCase());

        if (membro) {
            await membro.roles.remove(CARGO_BANIDO_ID).catch(() => {});
            await membro.roles.add(CARGO_ALLOWLIST_ID).catch(() => {});

            try {
                await membro.user.send({
                    embeds: [
                        criarEmbedBanner(
                            '🎉 UNBAN ACEITO',
                            `O seu pedido de unban no servidor **${guildPrincipal.name}** foi **APROVADO**!\n\n**Motivo:** ${motivo}\n**Staff Responsável:** <@${interaction.user.id}>`
                        )
                    ]
                });
            } catch (err) {}

            return interaction.editReply({ embeds: [criarEmbedBanner('🔓 UNBAN APROVADO', `**Jogador:** <@${membro.id}>\n**Motivo:** ${motivo}\n📩 Notificação enviada por DM!`)] });
        }
        return interaction.editReply({ content: '❌ Jogador não localizado no servidor.' });
    }

    if (interaction.isButton() && interaction.customId === 'btn_fechar_ticket') {
        await interaction.reply({ content: '🔒 Ticket encerrado.' });
        setTimeout(() => interaction.channel.delete().catch(() => {}), 4000);
    }
});

// APAGAR CALLS VAZIAS
setInterval(() => {
    callsAtivas.forEach(async (canalId, userId) => {
        const guild = client.guilds.cache.get(ID_SERVIDOR_PRINCIPAL);
        if (!guild) return;
        const canal = guild.channels.cache.get(canalId);

        if (canal && canal.members.size === 0) {
            await canal.delete().catch(() => {});
            callsAtivas.delete(userId);
        }
    });
}, 300000);

client.login("MTU0NTkzNDk3NzkwMjk2ODk0Mg.Gn3M49.ccsApn_q3SJLN6rO6P87QU82AELSrL5XPfNWTA");